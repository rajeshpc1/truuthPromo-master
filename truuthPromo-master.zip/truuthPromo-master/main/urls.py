from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="main-home"),
    path('multiple/', views.multiple, name="main-multiple"),
    path('pwned-check/', views.pwnedcheck, name="main-pwnedcheck"),
    path('pwned-check-two/', views.pwnedchecktwo, name="main-pwnedchecktwo"),
]