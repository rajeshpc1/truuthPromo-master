from django.shortcuts import render, redirect
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
import requests
import os

def home(request):
    return render(request, 'main/index.html')

def multiple(request):
    return render(request, 'main/multiple.html')

def pwnedchecktwo(request):
    userEmailOne = request.POST["userEmail"]
    userEmailTwo = request.POST["userEmail2"]
    userEmailThree = request.POST["userEmail3"]

    allData = {}

    url = 'https://haveibeenpwned.com/api/v3/breachedaccount/' + userEmailOne
    headers = {'hibp-api-key': os.environ.get('HIBP_API_KEY', True)}
    dataOne = requests.get(url, headers=headers)
    if (len(dataOne.text) == 0):
        allData['dataOne'] = {}
    else:
        dataOne = dataOne.json()
        allData['dataOne'] = dataOne

    url = 'https://haveibeenpwned.com/api/v3/breachedaccount/' + userEmailTwo
    headers = {'hibp-api-key': os.environ.get('HIBP_API_KEY', True)}
    dataTwo = requests.get(url, headers=headers)
    if (len(dataTwo.text) == 0):
        allData['dataTwo'] = {}
    else:
        dataTwo = dataTwo.json()
        allData['dataTwo'] = dataTwo

    url = 'https://haveibeenpwned.com/api/v3/breachedaccount/' + userEmailThree
    headers = {'hibp-api-key': os.environ.get('HIBP_API_KEY', True)}
    dataThree = requests.get(url, headers=headers)
    if (len(dataThree.text) == 0):
        allData['dataThree'] = {}
    else:
        dataThree = dataThree.json()
        allData['dataThree'] = dataThree

    return render(request, 'main/results.html', allData)

def pwnedcheck(request):
    userEmail = request.POST["userEmail"]
    userName = request.POST["userName"]

    subject = 'Truuth / Have I Been Pwned?'
    url = 'https://haveibeenpwned.com/api/v3/breachedaccount/' + userEmail
    headers = {'hibp-api-key': os.environ.get('HIBP_API_KEY', True)}
    data = requests.get(url, headers=headers)
    isEmpty = False
    if(len(data.text) == 0):
        isEmpty = True
    else:
        data = data.json()
    html_message = render_to_string('response.html', {
        'logo':'https://static.wixstatic.com/media/8099b1_5e66101ecbad4a68b928463e795e624b~mv2.png',
        'data':data,
        'name':userName,
        'empty':isEmpty
    })

    from_email = 'Truuth <rajesh.purushothama@locii.id>'
    finalEmail = EmailMessage(
        subject,
        html_message,
        from_email,
        [userEmail]
    )
    finalEmail.content_subtype = "html"
    finalEmail.send()

    return redirect('/')
