import os
EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp-relay.sendinblue.com'
EMAIL_HOST_USER = 'cooper.timewell@gmail.com'
EMAIL_HOST_PASSWORD = os.environ.get('SMTP_KEY', True)
EMAIL_PORT = 587